var targets = []; //variable that stores how many letters are being displayed for V10 just make target have 10 elements
var counter = 60; // counts the number of seconds that has passed
var isY = false; // whether the current screen contains a Y
var hasBeenClicked = false; // whether the user clicked the screen
var refreshRate = 60; // how fast the screen refreshes in seconds
var freq = 10; // the frequency of Y's the higher the number lower the frequency.
var totalClicks = 0; //total number of clicks that user did in the session.
var correctHits = 0; // the number of times the user got a correct hits
var falseAlarms = 0; // the total number of times the user got a false alarm.
var totalYs = 0; // the total amount of Y's that are in the session.
var isPaused = true; // whether the activity is paused or not.
var heightShift = -25;
var numberOfLetters =10; //number of letters on the screen.

var hits1 = 0.0;
var falseAlarm1 = 0.0;
var name1 = 'abc';
var email1 = 'test@abc.com';

var url = 'https://script.google.com/macros/s/AKfycbwD2DssxONULQH1IgRtVTozzG27HXhhJJSEocUpLQwb2HwtC-c/exec';
function setup() {
	$('.start').click(function() {
        // hide the instructions
        $('#instr').hide();
		//creating canvas and set up.
		isPaused = false;
		createCanvas(window.innerWidth, window.innerHeight);
		background(0);
		frameRate(refreshRate);
		genLetters();

		//setting up the buttons.
		button = createButton('Response');
		button.position(window.innerWidth/2-30, window.innerHeight+heightShift);
		button.mousePressed(seenY);
		pauseButton = createButton('Analyze');
		pauseButton.position(window.innerWidth/2 +250, window.innerHeight+heightShift);
		pauseButton.mousePressed(pauseFunc);
		pauseFeature = createButton('Pause');
		pauseFeature.position(window.innerWidth/2 + 340, window.innerHeight + heightShift);
		pauseFeature.mousePressed(pausingFunction);
		playFeature = createButton('Play');
		playFeature.position(window.innerWidth/2 + 400, window.innerHeight + heightShift);
		playFeature.mousePressed(playFunction);
        
        //getting data from the form
        name1 = $('#studentname').val();
        email1 = $('#studentemail').val();

	})




}


function draw() {

	if(!isPaused) {
		fill(255);
		counter++;
		textSize(10);
		for (var i = 0; i < targets.length; i++){
			text(targets[i][0], targets[i][1], targets[i][2]);
		}
		if (counter % refreshRate === 0){
			hasBeenClicked = false;

			isY = false;
			genLetters();

			background(0);
		}
	}

}

function seenY() {
	if (!hasBeenClicked){
		totalClicks++;
		if (isY){
			correctHits++;
		}else{
			falseAlarms++;
		}
		hasBeenClicked = true;
	}
}

//initializing the letters on the screen.
function genLetters(){
	targets = [];
	for (var i = 0; i < numberOfLetters; i++){
		var letter = 'V';
		var temp = (int)(Math.random() * freq)
		if (temp === 1 && !isY){
			isY = true;
			totalYs++;
			letter = 'Y';
		}
		targets.push([letter, Math.random()*window.innerWidth*.7, Math.random()*window.innerHeight*.7]);

	}

	targets.push([counter/60, width/2 -70,height -79]);
}

// the termination function
function pauseFunc() {
	noLoop();
	$('.results').html('<h2>Results - Version 10</h2> ' + '<div> Hits: ' +  correctHits/totalYs + '   ' +
	'<br>FA: ' + falseAlarms/((counter/60) - totalYs) +  '  </div>');
    // create submit button
    finalsubmit = createButton('SUBMIT SCORES');
    finalsubmit.position(window.innerWidth/4, 25);
    finalsubmit.mousePressed(final_submit);
    falseAlarm1 = falseAlarms/((counter/60) - totalYs);
    hits1 = correctHits/totalYs;
}

//the play function
function playFunction() {
	isPaused = false;

}
//the pause function.
function pausingFunction() {
	isPaused = true;

}

function final_submit(){
    $.post( url, { Name:name1, Email:email1, Hits:hits1, Fa:falseAlarm1 } );
    alert("Score has been submitted. Please check the google sheet. If it doesn't appear, record your score and email it to the TA!");
}